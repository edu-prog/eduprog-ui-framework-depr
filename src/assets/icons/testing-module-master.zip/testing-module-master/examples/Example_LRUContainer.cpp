#include <container/lru.h>

bool example() {
    container::LruContainer<std::string> lru(1024);
    lru.Put("Hello, world!");
    return lru.Has("Hello, world!");
}