#include <TestingModule/TestCase.hpp>

// This is an example of valid code in C++17 and higher.
bool example_one() {
    TestCase a {10, 20};
    TestCase b {10, 10};
    return a == b; // false
};

// This is an example of valid code in C++14 and lower.
bool example_two() {
    TestCase<int, int> a {10, 20};
    TestCase<int, int> b {10, 10};
    return a == b; // false
};

bool example_tree() {
    auto test_case = TestCase<int, int>::Deserialize("{\"input_expression\": 10, \"output_expression\": 20}");
    std::cout << test_case << std::endl;
}