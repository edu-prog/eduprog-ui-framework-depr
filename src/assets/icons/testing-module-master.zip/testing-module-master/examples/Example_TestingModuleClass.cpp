#include <TestingModule/TestingModule.hpp>

void example() {
    TestingModule<int, int> module("print(\"Hello, world\")", R"[{"input": "10", "output": "Hello, world"}]", ProgrammingLanguage::PYTHON)
}
