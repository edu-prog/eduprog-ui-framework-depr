#include <iostream>
#include <TestingModule/TestingModule.hpp>
#include <boost/program_options.hpp>


int main(int argc, char ** argv) {
    namespace opt = boost::program_options;
    opt::options_description desc("All options");

    desc.add_options()(
        "source_code,c", opt::value<std::string>()->required(), "Code that will be tested.")(
        "unit_tests,t",
        opt::value<std::string>()->required(),
        "Tests with which the program will run.")("language,l",
                                                  opt::value<std::string>()->required(),
                                                  "Programming language, which is used in source "
                                                  "code.")(
        "time_limit,t",
        opt::value<uint64_t>()->default_value(config::kUnboundedTimeLimit),
        "the time limit that is allowed for the "
        "execution of the program in the "
        "testing system.")("memory_limit,m",
                           opt::value<uint64_t>()->default_value(config::kUnboundedMemoryLimit),
                           "the RAM limit, "
                           "which is allowed "
                           "for the execution "
                           "of the program in "
                           "the testing "
                           "system.")("help,h",
                                      "Display "
                                      "the "
                                      "informati"
                                      "on.");

    opt::variables_map variables_map;
    opt::store(opt::parse_command_line(argc, argv, desc), variables_map);

    if (variables_map.count("help")) {
        std::cout << desc << '\n';
        return 1;
    }

    try {
        opt::notify(variables_map);
    } catch (const opt::required_option & exception) {
        std::cerr << "Error: " << exception.what() << '\n';
        return 2;
    }

    TestingModule<int, int> testing_module(variables_map["source_code"].as<std::string>(),
                                           variables_map["unit_tests"].as<std::string>().c_str(),
                                           variables_map["language"].as<std::string>());

    return 0;
}
