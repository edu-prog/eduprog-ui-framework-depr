#include <list>
#include <sstream>
#include <TestingModule/TestCaseJsonAnswer.hpp>
#include <TestingModule/TestCaseJsonWarnings.hpp>
#include <boost/json.hpp>
#include <gtest/gtest.h>

TEST(TestCaseJsonTest, TestCaseJsonTests) {
    TestCaseJsonAnswer tc{TestCaseWarnings::TIME_LIMIT};
    std::list<TestCaseJsonAnswer> tcl{
            TestCaseJsonAnswer(TestCaseWarnings::TIME_LIMIT),
            TestCaseJsonAnswer(TestCaseWarnings::COMPILATION_ERROR),
            TestCaseJsonAnswer(TestCaseWarnings::SUCCESS),
            TestCaseJsonAnswer(TestCaseWarnings::MEMORY_LIMIT),
            TestCaseJsonAnswer(TestCaseWarnings::TIME_LIMIT)};


    ASSERT_TRUE("{\"test_status\":4}" == tc.Serialize());
    ASSERT_TRUE(
            "[{\"test_status\":4},{\"test_status\":1},{\"test_status\":0},{\"test_status\":5},{\"test_status\":4}]" ==
            TestCaseJsonAnswer::Serialize(tcl));
}