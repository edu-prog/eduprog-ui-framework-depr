#include <sstream>
#include <TestingModule/TestCase.hpp>
#include <gtest/gtest.h>

TEST(TestCaseTest, TestCaseTests) {
    TestCase a = {10, 20};
    TestCase b = {20, 10};

    std::stringstream ss;
    ss << TestCaseJson::ToJson(b);

    ASSERT_TRUE(a != b);
    ASSERT_FALSE(a == b);
    ASSERT_TRUE(TestCase(10, 20) == (TestCaseJson::FromJson<TestCase<int, int>>("{\"input_expression\":10,\"output_expression\":20}")));
    ASSERT_TRUE(ss.str() == "{\"input_expression\":20,\"output_expression\":10}");
}