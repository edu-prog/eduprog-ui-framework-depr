# Testing-module

[![Build Status](https://www.travis-ci.com/edu-prog/ep-stl.svg?token=TMzu3qpELZsXcqQvoYTK&branch=master)](https://www.travis-ci.com/edu-prog/ep-stl)

This microservice is designed to provide in-depth analysis of the programs sent by the users of the product.

## Table of Contents

- [Tools](#tools)
- [Contributing](#contributing)

## Installation

```shell
$ ./configure -b Debug
$ cmake --build build -j 4
```

## Tools

| Tools    | Motivation                                                                                                                                                                                                                       |
| -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| C++      | Since reading and running a file are time-consuming operations in the operating system itself, we need to reduce to a minimum the IDLE time that would take the program to run in addition to working with the operating system. |
| Postgres | We need a repository where we can store unit testing for all the tasks presented on the site.                                                                                                                                    |

## Contributing

Please contribute using Github Flow. Create a branch, add commits, and open a pull request.
