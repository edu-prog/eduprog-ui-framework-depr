#ifndef TESTING_MODULE_TESTCASEJSON_H
#define TESTING_MODULE_TESTCASEJSON_H

/**
 * @addtogroup testing_module
 * @{
 */

#include <span>
#include <string>
#include <TestingModule/TestCaseJsonWarnings.hpp>
#include <boost/json.hpp>
#include <fmt/core.h>

/**
 * @class TestCaseJsonAnswer
 * @brief This class provides the creation of a response for the test system.
 * @details This class is responsible for serializing the response of the testing system in Json.
 */
class TestCaseJsonAnswer {
public:
    /**
     * @brief This is a standard-initializing constructor.
     * @param test_case_status - warning that occurred as a result of the testing system.
     */
    explicit TestCaseJsonAnswer(TestCaseWarnings test_case_status)
        : test_case_warning_(test_case_status) {}

    /**
     * @brief This method serializes the fields of the current class in Json.
     * @return The result of serialization in Json format.
     */
    std::string Serialize() { return boost::json::serialize(boost::json::value_from(*this)); }

    /**
     * @brief This is getter to test_case_warning_ field.
     * @return return value of test_case_warning_ field
     */
    TestCaseWarnings TestCaseWarning() { return test_case_warning_; }

    /**
     * @brief This is getter to test_case_warning_ field which return constant value.
     * @return return const value of test_case_warning_ field
     */
    [[nodiscard]] TestCaseWarnings TestCaseWarning() const { return test_case_warning_; }

    /**
     * @brief This method serializes the list of fields of the current class in Json.
     * @param test_cases_result - list of TestCaseJsonAnswers
     * @return The result of serialization in Json format.
     */
    static std::string Serialize(std::list<TestCaseJsonAnswer> const & test_cases_result) {
        return boost::json::serialize(boost::json::value_from(test_cases_result));
    }

private:
    TestCaseWarnings test_case_warning_;
};

void tag_invoke(boost::json::value_from_tag,
                boost::json::value & json_value,
                TestCaseJsonAnswer const & test_case_json_answer) {
    json_value
        = {{"test_status", TestCaseWarningsMapping::Get(test_case_json_answer.TestCaseWarning())}};
}

/**
 * @}
 */

#endif //TESTING_MODULE_TESTCASEJSON_H
