#ifndef TESTING_MODULE_TESTINGMODULE_HPP
#define TESTING_MODULE_TESTINGMODULE_HPP

/**
 * @addtogroup testing_module
 * @{
 */

#include <TestingModule/ProgrammingLanguage.hpp>
#include <TestingModule/config.hpp>
#include <boost/process.hpp>
#include "TestCase.hpp"
#include "TestCaseJsonAnswer.hpp"

/**
 * @class TestingModule
 * @brief the class that implements the interfaces of the testing system.
 * @details The class includes many components that allow you to test various software components using a deterministic data set.
 * @tparam TestCaseInputType - the data type for the input data is TestCase.
 * @tparam TestCaseOutputType - the data type for the output data is TestCase.
 * @example Example_TestingModuleClass.cpp
*/
template <typename TestCaseInputType, typename TestCaseOutputType>
class TestingModule {
public:
    /*!
     * @brief constructor of class TestingModule.
     * @details This constructor processes the raw data passed by the user via string_view.
     * @param source_code - the source code of the program that should be tested.
     * @param unit_tests_json - tests for testing source code in json format
     * @param programming_language - the programming language in which the source code is written
     * @param time_limit - the time limit that is allowed for the execution of the program in the testing system.
     * @param memory_limit - the RAM limit, which is allowed for the execution of the program in the testing system.
     */
    TestingModule(std::string_view source_code,
                  const char * unit_tests_json,
                  std::string_view programming_language,
                  uint64_t time_limit = config::kUnboundedTimeLimit,
                  uint64_t memory_limit = config::kUnboundedMemoryLimit);

    /**
     * @brief This is the standard destructor for the TestingModule class
     * @details The list of UnitTests is cleared in the destructor.
     */
    ~TestingModule();

private:
    std::list<TestCase<TestCaseInputType, TestCaseOutputType>> unit_tests_;
    uint64_t time_limit_;
    uint64_t memory_limit_;
};

template <typename TestCaseInputType, typename TestCaseOutputType>
TestingModule<TestCaseInputType, TestCaseOutputType>::TestingModule(
    [[maybe_unused]] std::string_view source_code,
    [[maybe_unused]] const char * unit_tests_json,
    [[maybe_unused]] std::string_view programming_language,
    [[maybe_unused]] uint64_t time_limit,
    [[maybe_unused]] uint64_t memory_limit) {
    try {
        auto language = ProgrammingLanguageMapping::Get(programming_language);

        auto l = TestCaseJson::FromJson<std::list<TestCase<int, int>>>(unit_tests_json);
        std::cout << fmt::format("{} {}", l.front().input_expression_, l.front().output_expression_)
                  << '\n';

        if (language == ProgrammingLanguage::PYTHON) {
        }
    } catch (const std::logic_error & exception) {
        std::cerr << exception.what() << '\n';
        auto const * stacktrace = ep::receive_stacktrace(exception);
        if (stacktrace) {
            std::cerr << *stacktrace << '\n';
        }
    }
}

template <typename TestCaseInputType, typename TestCaseOutputType>
TestingModule<TestCaseInputType, TestCaseOutputType>::~TestingModule() {
    unit_tests_.clear();
}

/**
 * @}
 */

#endif //TESTING_MODULE_TESTINGMODULE_HPP