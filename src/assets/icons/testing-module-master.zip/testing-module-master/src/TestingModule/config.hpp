#ifndef TESTING_MODULE_CONFIR_HPP
#define TESTING_MODULE_CONFIR_HPP

/**
 * @addtogroup testing_module
 * @{
 */

#include <optional>
#include <ep_stl/strconv.hpp>

/**
 * @namespace config
 * @brief This namespace contains configuration constants
 * @details It contains many constants that can be used for various purposes.
 */
namespace config {
constexpr std::uint8_t kUnboundedTimeLimit
    = 0; ///< Unlimited program execution time in the testing system.
constexpr std::uint8_t kUnboundedMemoryLimit
    = 0; ///< Unlimited amount of execution RAM during the execution of the program in the testing system.
} // namespace config

/**
 * @}
 */

#endif //TESTING_MODULE_CONFIR_HPP
