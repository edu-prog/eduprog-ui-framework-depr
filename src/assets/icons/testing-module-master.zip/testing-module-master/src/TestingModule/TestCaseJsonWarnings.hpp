#ifndef TESTING_MODULE_TESTCASEJSONWARNINGS_HPP
#define TESTING_MODULE_TESTCASEJSONWARNINGS_HPP

/**
 * @addtogroup testing_module
 * @{
 */

#include <unordered_map>

/// The set of testing system warnings
enum TestCaseWarnings {
    SUCCESS, ///< The testing system found no errors in the program
    COMPILATION_ERROR, ///< The testing system failed to compile the program
    WRONG_ANSWER, ///< The testing system has diagnosed an incorrect program response
    PRESENTATION_ERROR, ///< The testing system has diagnosed an incorrect format of the program input data
    TIME_LIMIT, ///< The testing system has diagnosed an excess of the time limit of the program
    MEMORY_LIMIT, ///< The testing system has diagnosed an excess of the program's memory limit
    OUTPUT_LIMIT, ///< The testing system has diagnosed an incorrect format of the program output data
    RUNTIME_ERROR ///< The testing system has diagnosed a run-time error in the program
};

/**
 * @namespace detail
 * @brief This namespace is responsible for mapping TestCaseJson
 * @details This namespace contains unordered_map, which contains TestCaseWarnings and int.
 */
namespace detail {
static const std::unordered_map<TestCaseWarnings, int> test_case_warnings_map
    = {{TestCaseWarnings::SUCCESS, 0},
       {TestCaseWarnings::COMPILATION_ERROR, 1},
       {TestCaseWarnings::WRONG_ANSWER, 2},
       {TestCaseWarnings::PRESENTATION_ERROR, 3},
       {TestCaseWarnings::TIME_LIMIT, 4},
       {TestCaseWarnings::MEMORY_LIMIT, 5},
       {TestCaseWarnings::OUTPUT_LIMIT, 6},
       {TestCaseWarnings::RUNTIME_ERROR, 7}};
}

/**
 * @class TestCaseWarningsMapping
 * @brief This class is responsible for getting the error ID from TestCaseWarnings
 */
class TestCaseWarningsMapping {
public:
    /**
     * @brief This method is responsible for getting the error ID from TestCaseWarnings
     * @param warning - This is the warning from TestCaseWarnings
     * @return This method returns the warning id
     */
    static int Get(const TestCaseWarnings & warning) {
        auto it = detail::test_case_warnings_map.find(warning);

        if (it != detail::test_case_warnings_map.end()) {
            return it->second;
        }
        return -1;
    }
};

/**
 * @}
 */

#endif //TESTING_MODULE_TESTCASEJSONWARNINGS_HPP
