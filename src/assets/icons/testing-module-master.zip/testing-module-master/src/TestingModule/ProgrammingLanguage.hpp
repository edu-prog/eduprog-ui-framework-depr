#ifndef TESTING_MODULE_PROGRAMMINGLANGUAGE_HPP
#define TESTING_MODULE_PROGRAMMINGLANGUAGE_HPP

/**
 * @addtogroup testing_module
 * @{
 */

#include <boost/stacktrace.hpp>
#include <ep_stl/exception.hpp>
#include <fmt/core.h>

/// The set of programming languages that the testing system processes
enum class ProgrammingLanguage {
    PYTHON, ///< indicates that the source code in Python has been passed to the testing system.
    CPP, ///< indicates that the source code in C++ has been passed to the testing system.
};

/**
 * @namespace detail
 * @brief This is a service namespace.
 * @details This namespace contains the unordered_map for matching string and enum values.
 */
namespace detail {
/**
 * @fn programming_language_mapping
 * @brief This is unordered_map that contains matching programming language as string and enum
 */
static const std::unordered_map<std::string_view, ProgrammingLanguage> programming_language_mapping
    = {{"python", ProgrammingLanguage::PYTHON}, {"cpp", ProgrammingLanguage::CPP}};
} // namespace detail

/**
 * @class ProgrammingLanguageMapping
 * @brief This class is responsible for converting the enum programming language to a string.
 * @details Unordered_map stored in namespace detail is used for conversion.
 */
class ProgrammingLanguageMapping {
public:
    /**
     * @brief This is default-constructor for class ProgrammingLanguageMapping
     */
    ProgrammingLanguageMapping() = default;

    /**
     * @brief This is default-destructor for class ProgrammingLanguageMapping
     */
    ~ProgrammingLanguageMapping() = default;

    /**
     * @brief This method converts string to ProgrammingLanguage
     * @param str - string to be converted to ProgrammingLanguage.
     * @throws ProgrammingLanguageMappingException
     * @return ProgrammingLanguage - ProgrammingLanguage the enum attribute obtained from string.
     */
    static ProgrammingLanguage Get(std::string_view str) {
        auto it = detail::programming_language_mapping.find(str);

        if (it != detail::programming_language_mapping.end()) {
            return it->second;
        } else {
            ep::throw_with_trace(
                std::logic_error("You entered the wrong programming language name.\nCurrently "
                                 "supported:\n\tpython\n\tcpp\n"));
        }
        return ProgrammingLanguage{};
    }
};

/**
 * @}
 */

#endif //TESTING_MODULE_PROGRAMMINGLANGUAGE_HPP
