#ifndef TESTING_MODULE_TESTCASE_HPP
#define TESTING_MODULE_TESTCASE_HPP

/**
 * @addtogroup testing_module
 * @{
 */

#include <span>
#include <boost/json.hpp>
#include <fmt/core.h>

/**
 * @class TestCase
 * @brief interface for processing Test Cases.
 * @details This class describes the TestCase model, which serves as the main component for the test system.
 * @tparam TestCaseInputType - the data type for the input data is TestCase.
 * @tparam TestCaseOutputType - the data type for the output data is TestCase.
 * @example Example_TestCaseClass.cpp
 */
template <typename TestCaseInputType, typename TestCaseOutputType>
class TestCase {
public:
    TestCase() = default;
    /**
     * @brief This is copy-constructor for class TestCase.
     * @param other - other object with type TestCase<TestCaseInputType, TestCaseOutputType>
     */
    TestCase(const TestCase<TestCaseInputType, TestCaseOutputType> & other)
        : input_expression_(other.input_expression_),
          output_expression_(other.output_expression_) {}
    /**
     * @brief This is move-constructor for class TestCase.
     * @param other - other object with type TestCase<TestCaseInputType, TestCaseOutputType>
     * @remarks This move-constructor is noexcept.
     */
    TestCase(TestCase<TestCaseInputType, TestCaseOutputType> && other) noexcept
        : input_expression_(std::move(other.input_expression_)),
          output_expression_(std::move(other.output_expression_)) {}
    /**
     * @brief constructor of TestCase interface.
     * @details This constructor is required for processing and analyzing test cases specified by the user.
     * @param input_expression - input expression, can be specified in initializer_list.
     * @param output_expression - output expression, can be specified in initializer_list.
     */
    TestCase(TestCaseInputType input_expression, TestCaseOutputType output_expression)
        : input_expression_(input_expression), output_expression_(output_expression){};

    friend auto operator<=>(const TestCase &, const TestCase &) = default;

    TestCaseInputType input_expression_;
    TestCaseOutputType output_expression_;
};

template <typename TestCaseInputType, typename TestCaseOutputType>
TestCase<TestCaseInputType, TestCaseOutputType>
tag_invoke(boost::json::value_to_tag<TestCase<TestCaseInputType, TestCaseOutputType>>,
           boost::json::value const & json_value) {
    boost::json::object const & obj = json_value.as_object();
    return {boost::json::value_to<TestCaseInputType>(obj.at("input_expression")),
            boost::json::value_to<TestCaseInputType>(obj.at("output_expression"))};
}

template <typename TestCaseInputType, typename TestCaseOutputType>
void tag_invoke(boost::json::value_from_tag,
                boost::json::value & json_value,
                TestCase<TestCaseInputType, TestCaseOutputType> const & test_case) {
    json_value = {{"input_expression", test_case.input_expression_},
                  {"output_expression", test_case.output_expression_}};
}

/**
 * @namespace TestCaseJson
 * @brief This namespace contains JSON operations for TestCase class.
 */
namespace TestCaseJson {
/**
 * @fn ReturnType FromJson(const char * json)
* @brief Deserialize json to list of TestCase.
* @tparam ReturnType - type to which the json will be deserialized.
* @details This function deserialize json to ReturnType value structure using library boost::json by fields input_expression and output_expression.
* @param json - data with testing information.
* @return ReturnType value which can deserialized from json.
*/
template <typename ReturnType>
ReturnType FromJson(const char * json) {
    auto document = boost::json::parse(json);
    return boost::json::value_to<ReturnType>(document);
}

/**
 * @fn std::string ToJson(Type const & test_cases)
 * @brief Serialize test_cases value to json.
 * @details This function serialize test_cases value structure to json using library boost::json by fields input_expression and output_expression.
 * @tparam Type - test_case value type
 * @param test_cases - test_cases value
 * @return String which was serialized by test_cases value.
 */
template <typename Type>
std::string ToJson(Type const & test_cases) {
    return boost::json::serialize(boost::json::value_from(test_cases));
}
} // namespace TestCaseJson

/**
 * @}
 */

#endif //TESTING_MODULE_TESTCASE_HPP
