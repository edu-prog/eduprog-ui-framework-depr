---
name: Question
about: 'Add question about Eduprog: Testing module'
title: ''
labels: question
assignees: ''
---

Make sure to check documentation https://eduprog-docs.sviridovcomp.ru first. If the question is concise and probably has a short answer, asking it in Telegram chat https://t.me/joinchat/38qpkeBaAZpiNjky is probably the fastest way to find the answer.

If you still prefer GitHub issues, remove all this text and ask your question here.
